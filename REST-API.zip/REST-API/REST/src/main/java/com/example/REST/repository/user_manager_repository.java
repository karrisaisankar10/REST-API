package com.example.REST.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.REST.model.user_manager;

public interface user_manager_repository extends JpaRepository<user_manager, Integer>{

}
